import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'AutoDeploy — Publish your website', description: 'Deploy a prepared website template with one click.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body>{children}</body></html>; }
