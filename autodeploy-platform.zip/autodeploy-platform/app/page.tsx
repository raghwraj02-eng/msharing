'use client';
import { useState } from 'react';
type Platform = 'netlify' | 'vercel' | 'both';
type Result = { platform: string; ok: boolean; url?: string; message: string };
export default function Home() {
  const [name, setName] = useState('');
  const [platform, setPlatform] = useState<Platform>('netlify');
  const [secret, setSecret] = useState('');
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState<Result[]>([]);
  const [error, setError] = useState('');
  async function deploy(e: React.FormEvent) {
    e.preventDefault(); setError(''); setResults([]);
    const clean = name.trim().toLowerCase();
    if (!/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(clean)) { setError('Name 1–63 characters ka ho: lowercase letters, numbers aur hyphen.'); return; }
    setBusy(true);
    try {
      const response = await fetch('/api/deploy', { method: 'POST', headers: {'Content-Type':'application/json', ...(secret ? {'x-deploy-secret': secret} : {})}, body: JSON.stringify({ name: clean, platform }) });
      const data = await response.json();
      if (!response.ok) setError(data.error || 'Deployment start nahi ho saka. Environment settings check karein.');
      if (data.results) setResults(data.results);
    } catch { setError('Network error. Dobara try karein.'); } finally { setBusy(false); }
  }
  return <main className="shell"><nav className="nav"><div className="brand"><span className="brandIcon">↗</span> AutoDeploy</div><span className="navTag">ONE-CLICK PUBLISHING</span></nav>
    <section className="hero"><div className="pill"><span className="dot"/> YOUR WEBSITE, LIVE</div><h1>Ideas ko <span>online</span> le jao.</h1><p className="sub">Bas apni website ka naam enter karein. Hum aapki configured GitHub repository se website publish karne ki koshish karenge.</p>
    <form className="card" onSubmit={deploy}><label htmlFor="siteName">WEBSITE NAME</label><div className="nameBox"><span className="prefix">https://</span><input id="siteName" value={name} onChange={e=>setName(e.target.value)} placeholder="my-awesome-site" maxLength={63} autoComplete="off" required/><span className="suffix">.platform.app</span></div><p className="hint">Final URL hosting provider ke available subdomain par depend karega.</p>
      <label>DEPLOY WHERE?</label><div className="choices"><button type="button" className={platform==='netlify'?'choice active':'choice'} onClick={()=>setPlatform('netlify')}><span className="radio"/>Netlify</button><button type="button" className={platform==='vercel'?'choice active':'choice'} onClick={()=>setPlatform('vercel')}><span className="radio"/>Vercel</button><button type="button" className={platform==='both'?'choice active':'choice'} onClick={()=>setPlatform('both')}><span className="radio"/>Both</button></div>
      {process.env.NEXT_PUBLIC_REQUIRE_DEPLOY_SECRET === 'true' && <><label htmlFor="secret">ACCESS KEY</label><input className="secret" id="secret" type="password" value={secret} onChange={e=>setSecret(e.target.value)} placeholder="Deployment access key" required /></>}
      <button className="deployBtn" disabled={busy}>{busy ? <><span className="spinner"/> Deploying...</> : <>Deploy my website <span>↗</span></>}</button><div className="secure"><span>▣</span> Source repository is configured by the site owner</div>
    </form>
    {error && <div className="alert error">{error}</div>}
    {results.length>0 && <div className="results"><h2>Deployment results</h2>{results.map((r,i)=><div className="result" key={i}><span className={r.ok?'status good':'status bad'}>{r.ok?'✓':'!'}</span><div><strong>{r.platform}</strong><p>{r.message}</p>{r.url && <a href={r.url} target="_blank" rel="noreferrer">Open live website ↗</a>}</div></div>)}</div>}
    <div className="steps"><div><span>01</span><strong>Choose a name</strong><p>Pick a unique project slug.</p></div><div><span>02</span><strong>We publish it</strong><p>Server calls the provider API.</p></div><div><span>03</span><strong>Share the link</strong><p>Open your live website.</p></div></div>
    <footer>AutoDeploy <span>•</span> Built for simple static websites <span>•</span> API keys stay on the server</footer></section></main>;
}
