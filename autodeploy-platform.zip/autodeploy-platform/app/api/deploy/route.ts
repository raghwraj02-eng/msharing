import { NextRequest, NextResponse } from 'next/server';
import { deploy, validateName } from '@/lib/deploy';
export const runtime = 'nodejs';
export const maxDuration = 60;
export async function POST(req: NextRequest) {
  try {
    if (process.env.DEPLOY_SECRET && req.headers.get('x-deploy-secret') !== process.env.DEPLOY_SECRET) return NextResponse.json({ error: 'Access key incorrect hai.' }, { status: 401 });
    const body = await req.json();
    const name = validateName(body?.name);
    if (!name) return NextResponse.json({ error: 'Valid website name enter karein: 1–63 lowercase letters, numbers ya hyphens; start/end letter ya number se ho.' }, { status: 400 });
    const platform = body?.platform;
    if (!['netlify','vercel','both'].includes(platform)) return NextResponse.json({ error: 'Platform select karein.' }, { status: 400 });
    if ((platform === 'netlify' || platform === 'both') && !process.env.NETLIFY_AUTH_TOKEN) return NextResponse.json({ error: 'Netlify token server environment mein set nahi hai.' }, { status: 503 });
    if ((platform === 'vercel' || platform === 'both') && !process.env.VERCEL_TOKEN) return NextResponse.json({ error: 'Vercel token server environment mein set nahi hai.' }, { status: 503 });
    const results = await deploy(name, platform);
    const ok = results.some(r => r.ok);
    return NextResponse.json({ results }, { status: ok ? 200 : 502 });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Unexpected server error.' }, { status: 500 });
  }
}
