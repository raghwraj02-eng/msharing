import { NextRequest, NextResponse } from 'next/server';
import { validateName } from '@/lib/deploy';
export const runtime = 'nodejs';
export async function GET(req: NextRequest) {
  const name = validateName(req.nextUrl.searchParams.get('name'));
  if (!name) return NextResponse.json({ available: false, error: 'Invalid name.' }, { status: 400 });
  const checks: Record<string, unknown> = {};
  if (process.env.NETLIFY_AUTH_TOKEN) {
    const r = await fetch(`https://api.netlify.com/api/v1/sites?name=${encodeURIComponent(name)}`, { headers: { Authorization: `Bearer ${process.env.NETLIFY_AUTH_TOKEN}` }, cache: 'no-store' });
    checks.netlify = r.ok ? { available: !(await r.json() as Array<{ name?: string }>).some(s => s.name?.toLowerCase() === name) } : { available: null, error: 'Could not check Netlify.' };
  }
  if (process.env.VERCEL_TOKEN) {
    const url = new URL(`https://api.vercel.com/v5/projects/${encodeURIComponent(name)}`);
    if (process.env.VERCEL_TEAM_ID) url.searchParams.set('teamId', process.env.VERCEL_TEAM_ID);
    const r = await fetch(url, { headers: { Authorization: `Bearer ${process.env.VERCEL_TOKEN}` }, cache: 'no-store' });
    checks.vercel = r.status === 404 ? { available: true } : r.ok ? { available: false } : { available: null, error: 'Could not check Vercel.' };
  }
  return NextResponse.json({ name, checks });
}
