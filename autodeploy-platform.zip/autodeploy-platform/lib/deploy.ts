import AdmZip from 'adm-zip';
import { createHash } from 'crypto';

const GITHUB_REPOSITORY = process.env.GITHUB_REPOSITORY || 'raghwraj02-eng/msharing';
const GITHUB_BRANCH = process.env.GITHUB_BRANCH || 'main';
const SOURCE_DIR = (process.env.SOURCE_DIR || '').replace(/^\/+|\/+$/g, '');

function slugify(value: string) { return value.toLowerCase().trim(); }
export function validateName(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const name = slugify(value);
  return /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(name) ? name : null;
}
function githubArchiveUrl() {
  const [owner, repo] = GITHUB_REPOSITORY.split('/');
  if (!owner || !repo || GITHUB_REPOSITORY.includes('..')) throw new Error('GITHUB_REPOSITORY must be owner/repository.');
  return `https://codeload.github.com/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/zip/refs/heads/${encodeURIComponent(GITHUB_BRANCH)}`;
}
async function getWebsiteZip(): Promise<Buffer> {
  const response = await fetch(githubArchiveUrl(), { cache: 'no-store', signal: AbortSignal.timeout(25000) });
  if (!response.ok) throw new Error(`GitHub source download failed (${response.status}). Check repository visibility and branch name.`);
  const raw = Buffer.from(await response.arrayBuffer());
  if (raw.length > 40 * 1024 * 1024) throw new Error('Repository archive is larger than the 40 MB safety limit. Use a smaller static-site folder/repository.');
  const source = new AdmZip(raw);
  const entries = source.getEntries().filter(e => !e.isDirectory && !e.entryName.startsWith('__MACOSX/'));
  if (!entries.length) throw new Error('Repository archive has no files.');
  const top = entries[0].entryName.split('/')[0];
  const normalized = entries.map(e => ({ path: e.entryName.startsWith(`${top}/`) ? e.entryName.slice(top.length + 1) : e.entryName, data: e.getData() })).filter(e => e.path && !e.path.startsWith('../') && !e.path.includes('/../'));
  let prefix = SOURCE_DIR;
  if (!prefix) {
    const hasRootIndex = normalized.some(e => e.path === 'index.html');
    if (!hasRootIndex) {
      const candidates = ['dist', 'build', 'public', 'web/dist', 'web/build', 'web/public', 'web', 'frontend/dist', 'frontend/build', 'frontend/public', 'frontend'];
      prefix = candidates.find(c => normalized.some(e => e.path === `${c}/index.html`)) || '';
    }
  }
  const chosen = prefix ? normalized.filter(e => e.path.startsWith(`${prefix}/`)).map(e => ({ ...e, path: e.path.slice(prefix.length + 1) })) : normalized;
  if (!chosen.some(e => e.path === 'index.html')) throw new Error('No index.html found in selected source folder. This deployer currently supports static HTML/CSS/JS websites. Set SOURCE_DIR to the folder containing index.html, or use a repository with a built static site.');
  if (chosen.length > 2500) throw new Error('Website has more than 2,500 files; reduce the static site output before deploying.');
  const out = new AdmZip();
  for (const item of chosen) {
    if (item.path.startsWith('/') || item.path.split('/').includes('..')) continue;
    out.addFile(item.path, item.data);
  }
  return out.toBuffer();
}

async function deployNetlify(name: string, zip: Buffer) {
  const token = process.env.NETLIFY_AUTH_TOKEN;
  if (!token) throw new Error('NETLIFY_AUTH_TOKEN is not configured.');
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  const sitesResponse = await fetch('https://api.netlify.com/api/v1/sites?per_page=100', { headers, cache: 'no-store' });
  if (!sitesResponse.ok) throw new Error(`Netlify name check failed (${sitesResponse.status}).`);
  const sites = await sitesResponse.json() as Array<{ name?: string; id?: string; ssl_url?: string; url?: string }>;
  if (sites.some(s => s.name?.toLowerCase() === name)) throw new Error('That name already exists in your Netlify account. Choose another name.');
  const create = await fetch('https://api.netlify.com/api/v1/sites', { method: 'POST', headers, body: JSON.stringify({ name }) });
  const site = await create.json() as { id?: string; name?: string; ssl_url?: string; url?: string; message?: string };
  if (!create.ok || !site.id) throw new Error(site.message || `Netlify could not create the site (${create.status}). The subdomain may already be taken globally.`);
  const deploy = await fetch(`https://api.netlify.com/api/v1/sites/${site.id}/deploys`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/zip' }, body: new Uint8Array(zip), cache: 'no-store' });
  const data = await deploy.json() as { id?: string; state?: string; deploy_url?: string; ssl_url?: string; message?: string };
  if (!deploy.ok) throw new Error(data.message || `Netlify deploy failed (${deploy.status}). Site created, but its content did not deploy.`);
  const url = site.ssl_url || site.url || `https://${name}.netlify.app`;
  return { platform: 'Netlify', ok: true, url, message: `Site created; deployment status: ${data.state || 'processing'}.` };
}

async function deployVercel(name: string, zip: Buffer) {
  const token = process.env.VERCEL_TOKEN;
  if (!token) throw new Error('VERCEL_TOKEN is not configured.');
  const zipFile = new AdmZip(zip);
  const entries = zipFile.getEntries().filter(e => !e.isDirectory && e.entryName && !e.entryName.startsWith('/') && !e.entryName.split('/').includes('..'));
  if (!entries.some(e => e.entryName === 'index.html')) throw new Error('Vercel upload needs index.html at the website root.');
  if (entries.length > 2500) throw new Error('Website has more than 2,500 files; reduce the static site output.');
  const auth = { Authorization: `Bearer ${token}` };
  const files: Array<{ file: string; sha: string; size: number }> = [];
  for (const entry of entries) {
    const content = entry.getData();
    const sha = createHash('sha1').update(content).digest('hex');
    const uploadHeaders: Record<string, string> = { ...auth, 'Content-Type': 'application/octet-stream', 'x-vercel-digest': sha, 'Content-Length': String(content.length) };
    const uploadUrl = new URL('https://api.vercel.com/v2/files');
    if (process.env.VERCEL_TEAM_ID) uploadUrl.searchParams.set('teamId', process.env.VERCEL_TEAM_ID);
    const uploaded = await fetch(uploadUrl, { method: 'POST', headers: uploadHeaders, body: new Uint8Array(content), cache: 'no-store' });
    if (!uploaded.ok && uploaded.status !== 409) throw new Error(`Vercel file upload failed for ${entry.entryName} (${uploaded.status}).`);
    files.push({ file: entry.entryName, sha, size: content.length });
  }
  const payload: Record<string, unknown> = { name, files, projectSettings: { framework: null, buildCommand: null, outputDirectory: null, installCommand: null }, target: 'production' };
  const deploymentUrl = new URL('https://api.vercel.com/v13/deployments');
  if (process.env.VERCEL_TEAM_ID) deploymentUrl.searchParams.set('teamId', process.env.VERCEL_TEAM_ID);
  const response = await fetch(deploymentUrl, { method: 'POST', headers: { ...auth, 'Content-Type': 'application/json' }, body: JSON.stringify(payload), cache: 'no-store' });
  const data = await response.json() as { url?: string; id?: string; error?: { message?: string } };
  if (!response.ok || !data.url) throw new Error(data.error?.message || `Vercel deployment failed (${response.status}). Check token permissions and project-name availability.`);
  return { platform: 'Vercel', ok: true, url: data.url.startsWith('http') ? data.url : `https://${data.url}`, message: 'Deployment submitted. It may take a short time before the site is ready.' };
}

export async function deploy(name: string, platform: 'netlify' | 'vercel' | 'both') {
  const zip = await getWebsiteZip();
  const tasks = platform === 'both' ? [deployNetlify(name, zip), deployVercel(name, zip)] : [platform === 'netlify' ? deployNetlify(name, zip) : deployVercel(name, zip)];
  const settled = await Promise.allSettled(tasks);
  const results = settled.map((r, i) => {
    const p = platform === 'both' ? (i === 0 ? 'Netlify' : 'Vercel') : (platform === 'netlify' ? 'Netlify' : 'Vercel');
    if (r.status === 'fulfilled') return r.value;
    return { platform: p, ok: false, message: r.reason instanceof Error ? r.reason.message : 'Unknown deployment error.' };
  });
  return results;
}
